# Automatic build
Built website from `15b4cbe`. See https://github.com/ethereum/browser-solidity/ for details.
To use an offline copy, download `remix-15b4cbe.zip`.
